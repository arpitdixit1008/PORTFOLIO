import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { useInView } from 'react-intersection-observer';
import { Text, Float, OrbitControls } from '@react-three/drei';

interface Skill {
  name: string;
  icon: string;
  color: string;
  category: 'technical' | 'professional' | 'tools';
}

const SkillSphere: React.FC<{ skills: Skill[] }> = ({ skills }) => {
  return (
    <Canvas className="h-96">
      <ambientLight intensity={0.5} />
      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} />
      <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={1} />
      
      {skills.map((skill, index) => {
        // Position on sphere
        const phi = Math.acos(-1 + (2 * index) / skills.length);
        const theta = Math.sqrt(skills.length * Math.PI) * phi;
        const r = 3;
        
        return (
          <Float 
            key={skill.name}
            speed={2} 
            rotationIntensity={1} 
            floatIntensity={2}
            position={[
              r * Math.cos(theta) * Math.sin(phi),
              r * Math.sin(theta) * Math.sin(phi),
              r * Math.cos(phi)
            ]}
          >
            <Text
              color={skill.color}
              fontSize={0.3}
              maxWidth={0.1}
              lineHeight={1}
              letterSpacing={0.02}
              textAlign="center"
            >
              {skill.name}
            </Text>
          </Float>
        );
      })}
    </Canvas>
  );
};

const SkillCard: React.FC<{ title: string; skills: string[]; delay: number }> = ({ title, skills, delay }) => {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });
  
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5, delay: delay }}
      className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow duration-300"
    >
      <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">{title}</h3>
      
      <div className="flex flex-wrap gap-2">
        {skills.map((skill, index) => (
          <motion.span
            key={index}
            initial={{ opacity: 0, scale: 0 }}
            animate={inView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0 }}
            transition={{ duration: 0.3, delay: delay + (index * 0.05) }}
            className="px-3 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full text-sm"
          >
            {skill}
          </motion.span>
        ))}
      </div>
    </motion.div>
  );
};

const SkillsSection: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ 
    target: containerRef,
    offset: ["start end", "end start"] 
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [0, -50]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);
  
  const sphereSkills: Skill[] = [
    { name: 'Power BI', icon: 'chart-bar', color: '#f59e0b', category: 'tools' },
    { name: 'Tableau', icon: 'chart-line', color: '#10b981', category: 'tools' },
    { name: 'Excel', icon: 'table', color: '#3b82f6', category: 'tools' },
    { name: 'SQL', icon: 'database', color: '#6366f1', category: 'technical' },
    { name: 'Python', icon: 'code', color: '#8b5cf6', category: 'technical' },
    { name: 'SPSS', icon: 'calculator', color: '#ec4899', category: 'tools' },
    { name: 'Data Analysis', icon: 'chart-pie', color: '#f43f5e', category: 'technical' },
    { name: 'Communication', icon: 'speakerphone', color: '#06b6d4', category: 'professional' },
    { name: 'Problem Solving', icon: 'puzzle', color: '#fcd34d', category: 'professional' },
  ];
  
  const technicalSkills = [
    'Power BI', 'Tableau', 'SPSS', 'SQL', 'Python', 'Advanced Excel', 
    'MS-PowerPoint', 'MS-Word', 'Data Analysis'
  ];
  
  const professionalSkills = [
    'Effective Communication', 'Time Management', 'Lead Generation', 
    'Negotiation & Problem-solving', 'HR branding', 'Marketing', 
    'Sales', 'Accounting', 'Product Management'
  ];
  
  const languageSkills = [
    'English Proficiency (Spoken)', 'English Proficiency (Written)'
  ];

  return (
    <section 
      ref={containerRef} 
      className="min-h-screen w-full py-16 md:py-32 bg-gray-50 dark:bg-gray-900 transition-colors duration-500"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          style={{ y, opacity }}
          className="max-w-6xl mx-auto"
        >
          <motion.h2 
            className="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-blue-600 dark:text-blue-400">Skills &</span> Expertise
          </motion.h2>
          
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <div className="flex justify-center items-center">
              <div className="h-96 w-full">
                <SkillSphere skills={sphereSkills} />
              </div>
            </div>
            
            <div className="flex flex-col justify-center">
              <motion.h3
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="text-2xl font-semibold text-gray-900 dark:text-white mb-4"
              >
                A Diverse Skill Set
              </motion.h3>
              
              <motion.p
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.1 }}
                className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed"
              >
                With a strong foundation in business administration and various data analysis tools,
                I bring a well-rounded skill set that combines technical expertise with professional capabilities.
              </motion.p>
              
              <motion.p
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="text-gray-700 dark:text-gray-300 leading-relaxed"
              >
                My ability to analyze data, communicate effectively, and manage projects allows me to
                approach business challenges with a comprehensive perspective and innovative solutions.
              </motion.p>
            </div>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <SkillCard title="Technical Skills" skills={technicalSkills} delay={0.1} />
            <SkillCard title="Professional Skills" skills={professionalSkills} delay={0.2} />
            <SkillCard title="Language Skills" skills={languageSkills} delay={0.3} />
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default SkillsSection;