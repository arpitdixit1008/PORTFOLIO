import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Calendar, Award, BookOpen } from 'lucide-react';

interface TimelineItemProps {
  date: string;
  title: string;
  subtitle: string;
  description: string;
  icon: React.ReactNode;
  index: number;
}

const TimelineItem: React.FC<TimelineItemProps> = ({ date, title, subtitle, description, icon, index }) => {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });
  
  return (
    <motion.div
      ref={ref}
      className={`flex relative ${index % 2 === 0 ? 'md:flex-row-reverse' : 'md:flex-row'}`}
      initial={{ opacity: 0, y: 50 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <div className="flex flex-col items-center">
        <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center z-10">
          {icon}
        </div>
        <div className="w-0.5 h-full bg-gray-200 dark:bg-gray-700 -mt-2 z-0"></div>
      </div>
      
      <div className={`flex-1 mx-4 my-8 ${index % 2 === 0 ? 'md:mr-12 md:text-right' : 'md:ml-12'}`}>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300">
          <span className="inline-block px-3 py-1 text-xs font-medium text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/30 rounded-full mb-2">
            {date}
          </span>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-1">{title}</h3>
          <h4 className="text-md font-medium text-gray-600 dark:text-gray-400 mb-3">{subtitle}</h4>
          <p className="text-gray-700 dark:text-gray-300 text-sm">{description}</p>
        </div>
      </div>
    </motion.div>
  );
};

const ExperienceSection: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ 
    target: containerRef,
    offset: ["start end", "end start"] 
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [0, -50]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);
  
  const certifications = [
    {
      date: "Jul 2024 - Sep 2024",
      title: "Basic Of Inventory Management",
      subtitle: "TCS iON, Virtual",
      description: "Successfully completed a comprehensive course covering the fundamentals of inventory management, including inventory control, stock management, and supply chain logistics.",
      icon: <BookOpen className="w-6 h-6 text-blue-600 dark:text-blue-400" />
    },
    {
      date: "Jul 2024 - Sep 2024",
      title: "Google Analytics",
      subtitle: "Google, Virtual",
      description: "Demonstrated proficiency in Google Analytics, including data collection, processing, configuration, and reporting.",
      icon: <Award className="w-6 h-6 text-blue-600 dark:text-blue-400" />
    },
    {
      date: "May 2024 - Jul 2024",
      title: "Business Problem Identification For Certified Analyst Professional",
      subtitle: "Infosys Springboard, Virtual",
      description: "Successfully completed a course focused on identifying and analyzing business problems, enhancing skills in problem-solving and analytical thinking.",
      icon: <BookOpen className="w-6 h-6 text-blue-600 dark:text-blue-400" />
    },
    {
      date: "Feb 2024",
      title: "International Conference On Industrial, Systems & IT Engineering",
      subtitle: "PSIT College Of Higher Education, Kanpur",
      description: "Participated in an international conference focused on industrial, systems, and IT engineering, gaining insights into current challenges and opportunities.",
      icon: <Calendar className="w-6 h-6 text-blue-600 dark:text-blue-400" />
    },
    {
      date: "Oct 2023 - Jan 2024",
      title: "Advance Excel",
      subtitle: "Pranveer Singh Institute of Technology, Kanpur",
      description: "Successfully completed a course on advanced Excel techniques, enhancing skills in data analysis, spreadsheet management, and complex formula creation.",
      icon: <Award className="w-6 h-6 text-blue-600 dark:text-blue-400" />
    },
    {
      date: "Sep 2023 - Oct 2023",
      title: "MS Office",
      subtitle: "Infosys Springboard, Virtual",
      description: "Successfully completed a comprehensive course on MS Office, covering key applications such as Word, Excel, PowerPoint, and Outlook.",
      icon: <BookOpen className="w-6 h-6 text-blue-600 dark:text-blue-400" />
    }
  ];

  return (
    <section 
      ref={containerRef} 
      className="min-h-screen w-full py-16 md:py-32 bg-gray-100 dark:bg-gray-900 transition-colors duration-500"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          style={{ y, opacity }}
          className="max-w-4xl mx-auto"
        >
          <motion.h2 
            className="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-blue-600 dark:text-blue-400">Experience &</span> Certifications
          </motion.h2>
          
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 md:left-1/2 top-0 w-0.5 h-full bg-gray-200 dark:bg-gray-700 transform md:translate-x-px"></div>
            
            {/* Timeline items */}
            <div className="ml-12 md:ml-0">
              {certifications.map((cert, index) => (
                <TimelineItem
                  key={index}
                  date={cert.date}
                  title={cert.title}
                  subtitle={cert.subtitle}
                  description={cert.description}
                  icon={cert.icon}
                  index={index}
                />
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default ExperienceSection;