import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const AboutSection: React.FC = () => {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [0, -50]);
  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.8, 1], [0, 1, 1, 0]);
  
  const [inViewRef, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });
  
  const setRefs = (node: HTMLDivElement) => {
    // Assign to both refs
    ref.current = node;
    inViewRef(node);
  };

  return (
    <section className="min-h-screen w-full py-16 md:py-32 bg-gray-50 dark:bg-gray-900 transition-colors duration-500">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          ref={setRefs}
          style={{ y, opacity }}
          className="max-w-4xl mx-auto"
        >
          <motion.h2 
            className="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white mb-16"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.8, ease: [0.215, 0.61, 0.355, 1] }}
          >
            <span className="text-blue-600 dark:text-blue-400">About</span> Me
          </motion.h2>
          
          <div className="grid md:grid-cols-5 gap-8 items-center">
            <motion.div 
              className="md:col-span-2"
              initial={{ opacity: 0, x: -50 }}
              animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="relative">
                <div className="aspect-w-4 aspect-h-5 rounded-lg overflow-hidden bg-gradient-to-tr from-blue-500 to-indigo-600 shadow-xl">
                  <img
                    src="/profile-photo.jpg"
                    alt="Arpit Kumar Dixit"
                    className="w-full h-full object-cover mix-blend-overlay"
                  />
                </div>
                <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-blue-100 dark:bg-blue-900/30 rounded-full z-0"></div>
              </div>
            </motion.div>
            
            <motion.div 
              className="md:col-span-3"
              initial={{ opacity: 0, x: 50 }}
              animate={inView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                Enthusiastic BBA Student
              </h3>
              
              <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
                I am a passionate BBA student at Pranveer Singh Institute of Technology, Kanpur, 
                with a strong foundation in business administration and proficiency in data analytics tools 
                like Power BI, Tableau, and MS Excel.
              </p>
              
              <p className="text-gray-700 dark:text-gray-300 mb-8 leading-relaxed">
                My goal is to apply my analytical, technical, and management skills in a real-world 
                business environment. I'm particularly interested in leveraging data to drive business 
                decisions and strategy.
              </p>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">Education</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    BBA, Management<br />
                    Pranveer Singh Institute of Technology<br />
                    2023 - 2026
                  </p>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">Location</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Kanpur, India
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;