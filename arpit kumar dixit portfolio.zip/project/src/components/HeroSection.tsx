import React, { useRef } from 'react';
import { motion } from 'framer-motion';
import { Canvas, useFrame } from '@react-three/fiber';
import { useInView } from 'react-intersection-observer';
import { Text3D, Float, PerspectiveCamera, OrbitControls } from '@react-three/drei';
import { useNavigate } from 'react-router-dom';
import { ChevronDown } from 'lucide-react';

const AnimatedText: React.FC = () => {
  const ref = useRef<THREE.Group>(null);
  
  useFrame(({ clock }) => {
    if (ref.current) {
      ref.current.rotation.y = Math.sin(clock.getElapsedTime() * 0.3) * 0.1;
      ref.current.position.y = Math.sin(clock.getElapsedTime() * 0.5) * 0.1;
    }
  });

  return (
    <Float speed={2} rotationIntensity={0.2} floatIntensity={0.5}>
      <group ref={ref} position={[0, 0, 0]}>
        <Text3D
          font="/fonts/Inter_Bold.json"
          size={0.5}
          height={0.1}
          curveSegments={12}
          bevelEnabled
          bevelThickness={0.02}
          bevelSize={0.02}
          bevelOffset={0}
          bevelSegments={5}
          position={[-2, 0, 0]}
        >
          ARPIT
          <meshNormalMaterial />
        </Text3D>
      </group>
    </Float>
  );
};

const HeroSection: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: false,
    threshold: 0.1,
  });
  const navigate = useNavigate();
  
  const textVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 0.1 * i,
        duration: 0.8,
        ease: [0.215, 0.61, 0.355, 1]
      }
    })
  };

  return (
    <section 
      ref={ref} 
      className="min-h-screen w-full relative flex flex-col items-center justify-center bg-gradient-to-b from-white to-gray-100 dark:from-gray-900 dark:to-black transition-colors duration-500"
    >
      <div className="absolute inset-0 z-0">
        <Canvas className="w-full h-full">
          <PerspectiveCamera makeDefault position={[0, 0, 5]} />
          <ambientLight intensity={0.5} />
          <pointLight position={[10, 10, 10]} intensity={1} />
          <AnimatedText />
          <OrbitControls 
            enableZoom={false} 
            enablePan={false}
            rotateSpeed={0.3}
            autoRotate
            autoRotateSpeed={0.5}
          />
        </Canvas>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 z-10 text-center">
        <motion.div
          className="max-w-3xl mx-auto"
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          variants={{
            hidden: {},
            visible: {
              transition: {
                staggerChildren: 0.2
              }
            }
          }}
        >
          <motion.h2 
            className="text-xl md:text-2xl text-gray-600 dark:text-gray-400 mb-4"
            custom={1}
            variants={textVariants}
          >
            Hello, I'm
          </motion.h2>
          
          <motion.h1 
            className="text-4xl md:text-6xl lg:text-7xl font-bold text-gray-900 dark:text-white mb-6"
            custom={2}
            variants={textVariants}
          >
            Arpit Kumar Dixit
          </motion.h1>
          
          <motion.div 
            className="mb-8"
            custom={3}
            variants={textVariants}
          >
            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-400">
              BBA Student & Data Analytics Enthusiast
            </p>
          </motion.div>
          
          <motion.div
            custom={4}
            variants={textVariants}
            className="flex flex-col md:flex-row items-center justify-center gap-4"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-3 bg-blue-600 text-white font-medium rounded-full hover:bg-blue-700 transition-colors duration-300"
              onClick={() => navigate('/contact')}
            >
              Contact Me
            </motion.button>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-3 bg-transparent border-2 border-gray-300 dark:border-gray-700 text-gray-800 dark:text-gray-200 font-medium rounded-full hover:border-blue-500 hover:text-blue-600 dark:hover:text-blue-400 transition-colors duration-300"
              onClick={() => navigate('/about')}
            >
              Learn More
            </motion.button>
          </motion.div>
        </motion.div>
      </div>
      
      <motion.div 
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
        initial={{ y: -10, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ 
          y: { 
            duration: 1, 
            repeat: Infinity, 
            repeatType: "reverse", 
            ease: "easeInOut" 
          },
          opacity: { duration: 1, delay: 2 }
        }}
      >
        <ChevronDown className="w-8 h-8 text-gray-500 dark:text-gray-400" />
      </motion.div>
    </section>
  );
};

export default HeroSection;