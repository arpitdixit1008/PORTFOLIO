import {
  analytics,
  business,
  excel,
  powerbi,
  sql,
  tableau,
  python,
  tcs,
  infosys,
  google,
  carrent,
  jobit,
  tripguide,
} from "../assets";

export const navLinks = [
  {
    id: "about",
    title: "About",
  },
  {
    id: "education",
    title: "Education",
  },
  {
    id: "skills",
    title: "Skills",
  },
  {
    id: "certifications",
    title: "Certifications",
  },
  {
    id: "contact",
    title: "Contact",
  },
];

const services = [
  {
    title: "Business Analysis",
    icon: business,
  },
  {
    title: "Data Analytics",
    icon: analytics,
  },
  {
    title: "Financial Modeling",
    icon: excel,
  },
  {
    title: "Market Research",
    icon: powerbi,
  },
];

const technologies = [
  {
    name: "Excel",
    icon: excel,
  },
  {
    name: "Power BI",
    icon: powerbi,
  },
  {
    name: "SQL",
    icon: sql,
  },
  {
    name: "Tableau",
    icon: tableau,
  },
  {
    name: "Python",
    icon: python,
  },
];

const experiences = [
  {
    title: "Business Analyst Intern",
    company_name: "TCS",
    icon: tcs,
    iconBg: "#383E56",
    date: "March 2023 - August 2023",
    points: [
      "Analyzed business requirements and translated them into functional specifications.",
      "Conducted market research and competitor analysis to identify business opportunities.",
      "Created data visualizations and dashboards using Power BI to present insights to stakeholders.",
      "Participated in cross-functional team meetings to discuss project progress and challenges.",
    ],
  },
  {
    title: "Data Analytics Intern",
    company_name: "Infosys",
    icon: infosys,
    iconBg: "#E6DEDD",
    date: "Sept 2022 - Feb 2023",
    points: [
      "Assisted in data collection, cleaning, and analysis using Excel and SQL.",
      "Developed automated reports to track key performance indicators.",
      "Collaborated with the marketing team to analyze campaign performance.",
      "Presented findings and recommendations to senior management.",
    ],
  },
  {
    title: "Market Research Assistant",
    company_name: "Google",
    icon: google,
    iconBg: "#383E56",
    date: "Jan 2022 - June 2022",
    points: [
      "Conducted primary and secondary research to gather market intelligence.",
      "Analyzed consumer behavior and preferences using survey data.",
      "Created presentations summarizing research findings and insights.",
      "Assisted in developing marketing strategies based on research outcomes.",
    ],
  },
];

const testimonials = [
  {
    testimonial:
      "Arpit's analytical skills and attention to detail made him an invaluable asset to our team during his internship.",
    name: "Rajesh Kumar",
    designation: "Senior Manager",
    company: "TCS",
    image: "https://randomuser.me/api/portraits/men/4.jpg",
  },
  {
    testimonial:
      "I was impressed by Arpit's ability to quickly learn new tools and apply them to solve complex business problems.",
    name: "Priya Sharma",
    designation: "Data Analytics Lead",
    company: "Infosys",
    image: "https://randomuser.me/api/portraits/women/6.jpg",
  },
  {
    testimonial:
      "Arpit demonstrated exceptional communication skills and a strong business acumen during his time with us.",
    name: "Amit Patel",
    designation: "Marketing Director",
    company: "Google",
    image: "https://randomuser.me/api/portraits/men/1.jpg",
  },
];

const projects = [
  {
    name: "Sales Performance Dashboard",
    description:
      "Interactive Power BI dashboard that provides comprehensive insights into sales performance across different regions, products, and time periods, enabling data-driven decision making.",
    tags: [
      {
        name: "powerbi",
        color: "blue-text-gradient",
      },
      {
        name: "excel",
        color: "green-text-gradient",
      },
      {
        name: "sql",
        color: "pink-text-gradient",
      },
    ],
    image: carrent,
    source_code_link: "https://github.com/",
  },
  {
    name: "Market Segmentation Analysis",
    description:
      "A comprehensive analysis of customer segments based on demographic, behavioral, and psychographic factors, helping businesses target their marketing efforts more effectively.",
    tags: [
      {
        name: "python",
        color: "blue-text-gradient",
      },
      {
        name: "tableau",
        color: "green-text-gradient",
      },
      {
        name: "statistics",
        color: "pink-text-gradient",
      },
    ],
    image: jobit,
    source_code_link: "https://github.com/",
  },
  {
    name: "Financial Forecasting Model",
    description:
      "Advanced Excel model that forecasts financial performance based on historical data and market trends, helping businesses make informed decisions about resource allocation and investments.",
    tags: [
      {
        name: "excel",
        color: "blue-text-gradient",
      },
      {
        name: "financial-modeling",
        color: "green-text-gradient",
      },
      {
        name: "data-analysis",
        color: "pink-text-gradient",
      },
    ],
    image: tripguide,
    source_code_link: "https://github.com/",
  },
];

const certifications = [
  {
    title: "Google Data Analytics Professional Certificate",
    organization: "Google",
    date: "2023",
    description: "Comprehensive training in data analysis, including data cleaning, analysis, and visualization using various tools and techniques.",
    link: "https://www.coursera.org/professional-certificates/google-data-analytics",
  },
  {
    title: "Microsoft Power BI Data Analyst Associate",
    organization: "Microsoft",
    date: "2023",
    description: "Certification validating skills in designing and building scalable data models, cleaning and transforming data, and creating meaningful data visualizations.",
    link: "https://learn.microsoft.com/en-us/certifications/power-bi-data-analyst-associate/",
  },
  {
    title: "Financial Modeling & Valuation Analyst (FMVA)",
    organization: "Corporate Finance Institute",
    date: "2022",
    description: "Advanced certification in financial modeling, valuation, and analysis techniques used in investment banking, equity research, and corporate development.",
    link: "https://corporatefinanceinstitute.com/certifications/financial-modeling-valuation-analyst-fmva-program/",
  },
  {
    title: "SQL for Data Science",
    organization: "University of California, Davis",
    date: "2022",
    description: "Comprehensive course covering SQL fundamentals, filtering, sorting, calculating data, and working with different types of data.",
    link: "https://www.coursera.org/learn/sql-for-data-science",
  },
  {
    title: "Business Analytics Specialization",
    organization: "Wharton Online",
    date: "2021",
    description: "Specialization covering customer analytics, operations analytics, people analytics, and accounting analytics.",
    link: "https://www.coursera.org/specializations/business-analytics",
  },
  {
    title: "Tableau Desktop Specialist",
    organization: "Tableau",
    date: "2021",
    description: "Certification validating fundamental skills in Tableau Desktop to connect to, prepare, explore, and analyze data, and create basic visualizations and dashboards.",
    link: "https://www.tableau.com/learn/certification/desktop-specialist",
  },
];

export { services, technologies, experiences, testimonials, projects, certifications };