import { useState, useEffect } from 'react';
import { BrowserRouter } from 'react-router-dom';

import { About, Contact, Experience, Feedbacks, Hero, Navbar, Tech, Works, StarsCanvas, Certifications } from './components';
import { ThemeProvider } from './context/ThemeContext';
import { motion, AnimatePresence } from 'framer-motion';

const App = () => {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading assets
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <BrowserRouter>
      <ThemeProvider>
        <AnimatePresence>
          {loading ? (
            <motion.div 
              key="loader"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex justify-center items-center h-screen w-screen bg-primary"
            >
              <div className="flex flex-col items-center">
                <div className="w-32 h-32 relative">
                  <motion.div 
                    className="absolute inset-0 border-4 border-t-[#60a5fa] border-opacity-50 rounded-full"
                    animate={{ 
                      rotate: 360,
                      borderWidth: [4, 6, 4],
                      borderTopColor: ["#60a5fa", "#1e40af", "#60a5fa"]
                    }}
                    transition={{ 
                      duration: 1.5, 
                      repeat: Infinity, 
                      ease: "linear"
                    }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-white text-4xl font-bold">A.D</span>
                  </div>
                </div>
                <p className="text-[#c0c2c9] text-xl font-light mt-6">
                  Loading Portfolio...
                </p>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="content"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="relative z-0 bg-primary"
            >
              <div className="bg-hero-pattern bg-cover bg-no-repeat bg-center">
                <Navbar />
                <Hero />
              </div>
              <About />
              <Experience />
              <Tech />
              <Works />
              <Certifications />
              <Feedbacks />
              <div className="relative z-0">
                <Contact />
                <StarsCanvas />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </ThemeProvider>
    </BrowserRouter>
  );
};

export default App;