import React from "react";
import { motion } from "framer-motion";
import { BallCanvas } from "./canvas";
import { SectionWrapper } from "../hoc";
import { technologies } from "../constants";
import { styles } from "../styles";
import { textVariant, fadeIn } from "../utils/motion";

const Tech = () => {
  return (
    <>
      <motion.div variants={textVariant()}>
        <p className={`${styles.sectionSubText} text-center`}>
          My technical expertise
        </p>
        <h2 className={`${styles.sectionHeadText} text-center`}>
          Skills & Tools.
        </h2>
      </motion.div>

      <motion.p
        variants={fadeIn("", "", 0.1, 1)}
        className="mt-4 text-secondary text-[17px] max-w-3xl mx-auto text-center leading-[30px] mb-10"
      >
        I've developed a strong foundation in business analysis tools and technologies.
        Here are the key skills that enable me to transform data into actionable insights.
      </motion.p>

      <div className="flex flex-row flex-wrap justify-center gap-10">
        {technologies.map((technology) => (
          <div className="w-28 h-28" key={technology.name}>
            <BallCanvas icon={technology.icon} />
            <p className="text-center text-white mt-2">{technology.name}</p>
          </div>
        ))}
      </div>

      <div className="mt-16">
        <h3 className="text-white text-[24px] font-bold text-center mb-8">Additional Skills</h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <motion.div 
            variants={fadeIn("up", "spring", 0.2, 0.75)}
            className="glass-card p-6 rounded-lg"
          >
            <h4 className="text-white text-[18px] font-semibold mb-3">Business Analysis</h4>
            <ul className="list-disc pl-5 text-secondary">
              <li>Requirements Gathering</li>
              <li>Process Mapping</li>
              <li>Gap Analysis</li>
              <li>Stakeholder Management</li>
              <li>Business Case Development</li>
            </ul>
          </motion.div>

          <motion.div 
            variants={fadeIn("up", "spring", 0.4, 0.75)}
            className="glass-card p-6 rounded-lg"
          >
            <h4 className="text-white text-[18px] font-semibold mb-3">Data Analysis</h4>
            <ul className="list-disc pl-5 text-secondary">
              <li>Statistical Analysis</li>
              <li>Data Visualization</li>
              <li>Dashboard Creation</li>
              <li>ETL Processes</li>
              <li>Predictive Modeling</li>
            </ul>
          </motion.div>

          <motion.div 
            variants={fadeIn("up", "spring", 0.6, 0.75)}
            className="glass-card p-6 rounded-lg"
          >
            <h4 className="text-white text-[18px] font-semibold mb-3">Financial Skills</h4>
            <ul className="list-disc pl-5 text-secondary">
              <li>Financial Modeling</li>
              <li>Budgeting & Forecasting</li>
              <li>Cost-Benefit Analysis</li>
              <li>ROI Calculation</li>
              <li>Risk Assessment</li>
            </ul>
          </motion.div>

          <motion.div 
            variants={fadeIn("up", "spring", 0.8, 0.75)}
            className="glass-card p-6 rounded-lg"
          >
            <h4 className="text-white text-[18px] font-semibold mb-3">Project Management</h4>
            <ul className="list-disc pl-5 text-secondary">
              <li>Agile Methodologies</li>
              <li>Project Planning</li>
              <li>Resource Allocation</li>
              <li>Risk Management</li>
              <li>Status Reporting</li>
            </ul>
          </motion.div>

          <motion.div 
            variants={fadeIn("up", "spring", 1.0, 0.75)}
            className="glass-card p-6 rounded-lg"
          >
            <h4 className="text-white text-[18px] font-semibold mb-3">Communication</h4>
            <ul className="list-disc pl-5 text-secondary">
              <li>Presentation Skills</li>
              <li>Technical Writing</li>
              <li>Stakeholder Communication</li>
              <li>Data Storytelling</li>
              <li>Executive Reporting</li>
            </ul>
          </motion.div>

          <motion.div 
            variants={fadeIn("up", "spring", 1.2, 0.75)}
            className="glass-card p-6 rounded-lg"
          >
            <h4 className="text-white text-[18px] font-semibold mb-3">Industry Knowledge</h4>
            <ul className="list-disc pl-5 text-secondary">
              <li>Market Research</li>
              <li>Competitive Analysis</li>
              <li>Business Strategy</li>
              <li>Industry Trends</li>
              <li>Regulatory Compliance</li>
            </ul>
          </motion.div>
        </div>
      </div>
    </>
  );
};

export default SectionWrapper(Tech, "skills");