import React from 'react';
import { Html, useProgress } from '@react-three/drei';
import { motion } from 'framer-motion';

const CanvasLoader = () => {
  const { progress } = useProgress();
  
  return (
    <Html as='div' center>
      <div className="flex flex-col items-center justify-center">
        <div className="w-20 h-20 relative">
          <motion.div 
            className="absolute inset-0 border-4 border-t-[#1e40af] border-opacity-30 rounded-full"
            animate={{ rotate: 360 }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-white text-xl font-bold">{progress.toFixed(0)}%</span>
          </div>
        </div>
        <p className="text-[#c0c2c9] text-sm font-light mt-4">
          Loading content...
        </p>
      </div>
    </Html>
  );
};

export default CanvasLoader;