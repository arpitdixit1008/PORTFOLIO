import React, { useState } from "react";
import { motion } from "framer-motion";
import { styles } from "../styles";
import { SectionWrapper } from "../hoc";
import { certifications } from "../constants";
import { fadeIn, textVariant, staggerContainer } from "../utils/motion";

const CertificationCard = ({ index, title, organization, date, description, link }) => {
  const [isFlipped, setIsFlipped] = useState(false);

  return (
    <motion.div
      variants={fadeIn("up", "spring", index * 0.5, 0.75)}
      className="w-full sm:w-[350px]"
      whileHover={{ scale: 1.05 }}
    >
      <div 
        className={`card-3d-wrapper w-full h-full cursor-pointer`} 
        onClick={() => setIsFlipped(!isFlipped)}
        style={{ transformStyle: "preserve-3d", perspective: "1000px" }}
      >
        <motion.div
          className="relative glass-card p-5 rounded-2xl w-full h-[380px] flex flex-col justify-between"
          animate={{ rotateY: isFlipped ? 180 : 0 }}
          transition={{ duration: 0.6 }}
          style={{ 
            backfaceVisibility: "hidden",
            WebkitBackfaceVisibility: "hidden",
            position: isFlipped ? "absolute" : "relative"
          }}
        >
          <div>
            <div className="w-full flex justify-between items-center">
              <div className="w-12 h-12 rounded-full bg-white flex justify-center items-center">
                <div className="w-10 h-10 rounded-full bg-[#1e40af] flex justify-center items-center">
                  <p className="text-white text-[22px] font-bold">{index + 1}</p>
                </div>
              </div>
              <p className="text-white text-[14px]">{date}</p>
            </div>

            <h3 className="text-white font-bold text-[24px] mt-5">{title}</h3>
            <p className="text-secondary text-[18px] mt-2">{organization}</p>
          </div>

          <div className="mt-5 flex flex-col">
            <p className="text-white text-[14px] italic">Click to view details</p>
            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="mt-3 bg-[#1e40af] py-2 px-4 rounded-xl w-fit text-white text-[14px] font-semibold flex items-center gap-2"
              onClick={(e) => {
                e.stopPropagation();
                window.open(link, "_blank");
              }}
            >
              View Certificate
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                <path fillRule="evenodd" d="M8.636 3.5a.5.5 0 0 0-.5-.5H1.5A1.5 1.5 0 0 0 0 4.5v10A1.5 1.5 0 0 0 1.5 16h10a1.5 1.5 0 0 0 1.5-1.5V7.864a.5.5 0 0 0-1 0V14.5a.5.5 0 0 1-.5.5h-10a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h6.636a.5.5 0 0 0 .5-.5z"/>
                <path fillRule="evenodd" d="M16 .5a.5.5 0 0 0-.5-.5h-5a.5.5 0 0 0 0 1h3.793L6.146 9.146a.5.5 0 1 0 .708.708L15 1.707V5.5a.5.5 0 0 0 1 0v-5z"/>
              </svg>
            </motion.div>
          </div>
        </motion.div>

        <motion.div
          className="absolute top-0 left-0 glass-card p-5 rounded-2xl w-full h-[380px] flex flex-col"
          animate={{ rotateY: isFlipped ? 0 : -180 }}
          transition={{ duration: 0.6 }}
          style={{ 
            backfaceVisibility: "hidden",
            WebkitBackfaceVisibility: "hidden"
          }}
        >
          <h3 className="text-white font-bold text-[20px] mb-4">About this certification</h3>
          <p className="text-secondary text-[16px] flex-grow">{description}</p>
          
          <div className="mt-5 flex flex-col">
            <p className="text-white text-[14px] italic">Click to flip back</p>
            <motion.div 
              whileHover={{ scale: 1.05 }}
              className="mt-3 bg-[#1e40af] py-2 px-4 rounded-xl w-fit text-white text-[14px] font-semibold flex items-center gap-2"
              onClick={(e) => {
                e.stopPropagation();
                window.open(link, "_blank");
              }}
            >
              View Certificate
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" viewBox="0 0 16 16">
                <path fillRule="evenodd" d="M8.636 3.5a.5.5 0 0 0-.5-.5H1.5A1.5 1.5 0 0 0 0 4.5v10A1.5 1.5 0 0 0 1.5 16h10a1.5 1.5 0 0 0 1.5-1.5V7.864a.5.5 0 0 0-1 0V14.5a.5.5 0 0 1-.5.5h-10a.5.5 0 0 1-.5-.5v-10a.5.5 0 0 1 .5-.5h6.636a.5.5 0 0 0 .5-.5z"/>
                <path fillRule="evenodd" d="M16 .5a.5.5 0 0 0-.5-.5h-5a.5.5 0 0 0 0 1h3.793L6.146 9.146a.5.5 0 1 0 .708.708L15 1.707V5.5a.5.5 0 0 0 1 0v-5z"/>
              </svg>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </motion.div>
  );
};

const Certifications = () => {
  return (
    <motion.section variants={staggerContainer()}>
      <motion.div variants={textVariant()}>
        <p className={`${styles.sectionSubText} text-center`}>My credentials</p>
        <h2 className={`${styles.sectionHeadText} text-center`}>Certifications.</h2>
      </motion.div>

      <motion.p
        variants={fadeIn("", "", 0.1, 1)}
        className="mt-4 text-secondary text-[17px] max-w-3xl mx-auto text-center leading-[30px] mb-10"
      >
        I've earned several industry-recognized certifications that validate my skills and knowledge in business analysis, data analytics, and related fields. These certifications demonstrate my commitment to continuous learning and professional development.
      </motion.p>

      <div className="mt-10 flex flex-wrap gap-10 justify-center">
        {certifications.map((certification, index) => (
          <CertificationCard key={`certification-${index}`} index={index} {...certification} />
        ))}
      </div>
    </motion.section>
  );
};

export default SectionWrapper(Certifications, "certifications");